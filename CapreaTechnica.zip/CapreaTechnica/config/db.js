module.exports = {
    url: 'mongodb://localhost/stencil-dev'
}