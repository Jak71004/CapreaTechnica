// public/js/app.js
(function(){
   angular.module('sampleApp', ['ngRoute', 'appRoutes', 'MainCtrl', 'AdminCtrl', 'AdminService', 'SignUpService']); 
}());
